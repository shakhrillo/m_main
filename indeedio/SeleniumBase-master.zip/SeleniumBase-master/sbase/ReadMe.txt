"SBase" is the short name of "SeleniumBase".
Use with console scripts: "python -m sbase".
