#!/bin/bash
set -e
echo "***** SeleniumBase Docker Machine *****"
exec "$@"
