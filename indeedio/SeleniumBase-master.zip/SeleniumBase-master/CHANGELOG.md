<h2><img src="https://seleniumbase.github.io/img/logo6.png" title="SeleniumBase" width="32" /> CHANGELOG</h2>

## See: [SeleniumBase/releases](https://github.com/seleniumbase/SeleniumBase/releases) 🗂️ 📋

### (For CDP updates, see the [CDP Mode docs](https://github.com/seleniumbase/SeleniumBase/blob/master/examples/cdp_mode/ReadMe.md))
