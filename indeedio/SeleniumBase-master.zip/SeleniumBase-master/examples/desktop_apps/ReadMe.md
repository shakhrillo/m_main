<h3 align="left"><img src="https://seleniumbase.github.io/cdn/img/sb_logo_b.png" alt="SeleniumBase" width="320" /></h3>

<h2><img src="https://seleniumbase.github.io/img/logo6.png" title="SeleniumBase" width="32" /> Desktop Apps</h2>

* **Recorder** (Run using ``python recorder.py`` or ``sbase recorder``)
