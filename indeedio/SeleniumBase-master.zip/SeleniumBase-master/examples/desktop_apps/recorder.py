""" Run this file using ``python recorder.py`` """

import os


def open_recorder_desktop_app():
    command = "sbase recorder"
    os.system(command)


if __name__ == "__main__":
    open_recorder_desktop_app()
