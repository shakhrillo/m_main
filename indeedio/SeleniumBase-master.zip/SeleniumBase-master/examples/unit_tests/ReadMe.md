<!-- SeleniumBase Docs -->

### <img src="https://seleniumbase.github.io/img/logo3.png" title="SeleniumBase" width="20" /> pytest-specific unit tests

The tests in this folder are for basic verification of the SeleniumBase framework with pytest.
