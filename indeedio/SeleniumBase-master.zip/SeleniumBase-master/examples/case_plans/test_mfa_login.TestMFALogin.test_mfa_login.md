``test_mfa_login.py::TestMFALogin::test_mfa_login``
---
| # | Step Description | Expected Result |
| - | ---------------- | --------------- |
| 1 | Open https://seleniumbase.io/realworld/login <br /> Enter credentials and Sign In. | Sign In was successful. |
| 2 | Click the ``This Page`` button. <br /> Save a screenshot to the logs. | |
| 3 | Click to Sign Out | Sign Out was successful. |
