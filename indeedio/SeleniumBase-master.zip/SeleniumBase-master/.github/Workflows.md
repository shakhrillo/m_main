### <img src="https://seleniumbase.github.io/img/logo6.png" title="SeleniumBase" width="32" /> SeleniumBase Workflows

> **Table of Contents / Navigation:**
> - [**CI build**](workflows/python-package.yml)
